M = {}
M.data = {
  title = "",
  active = false,
}
return M