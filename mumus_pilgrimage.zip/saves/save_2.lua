M = {}
M.data = {
  active = false,
  title = "",
}
return M