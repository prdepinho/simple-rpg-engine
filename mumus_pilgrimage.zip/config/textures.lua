textures = {
  font = "font.png",
  gui = "font.png",
  tiled_tileset = "tiled_tileset.png",
  overworld_tileset = "overworld_tileset.png",
  mansion_tileset = "mansion_tileset.png",
  castle_tileset = "castle_tileset.png",
  temple_tileset = "temple_tileset.png",
  neather_world_tileset = "neather_world_tileset.png",
  houses_tileset = "houses_tileset.png",
  sprites = "sprite_sheet.png",
  items = "items.png",
  effects = "effects.png",
}
