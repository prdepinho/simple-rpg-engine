function start_game()
  io.write('starting game')
  sfml_game_start()
end

function log(msg)
  io.write(msg)
  return(1)
end
