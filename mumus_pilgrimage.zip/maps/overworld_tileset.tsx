<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="overworld_tileset" tilewidth="16" tileheight="16" tilecount="256" columns="16">
 <image source="../assets/overworld_tileset.png" trans="ff00ff" width="256" height="256"/>
 <tile id="17">
  <animation>
   <frame tileid="17" duration="500"/>
   <frame tileid="18" duration="500"/>
  </animation>
 </tile>
 <tile id="21">
  <animation>
   <frame tileid="21" duration="500"/>
   <frame tileid="22" duration="500"/>
  </animation>
 </tile>
</tileset>
