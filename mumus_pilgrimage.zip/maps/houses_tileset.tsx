<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="houses_tileset" tilewidth="16" tileheight="16" tilecount="256" columns="16">
 <image source="../assets/houses_tileset.png" trans="ff00ff" width="256" height="256"/>
 <tile id="185">
  <animation>
   <frame tileid="185" duration="500"/>
   <frame tileid="186" duration="500"/>
  </animation>
 </tile>
 <tile id="187">
  <animation>
   <frame tileid="187" duration="500"/>
   <frame tileid="188" duration="500"/>
  </animation>
 </tile>
 <tile id="197">
  <animation>
   <frame tileid="197" duration="500"/>
   <frame tileid="198" duration="500"/>
  </animation>
 </tile>
</tileset>
