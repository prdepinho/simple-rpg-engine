<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="neather_world_tileset" tilewidth="16" tileheight="16" tilecount="256" columns="16">
 <image source="../assets/neather_world_tileset.png" trans="ff00ff" width="256" height="256"/>
 <tile id="74">
  <animation>
   <frame tileid="74" duration="500"/>
   <frame tileid="75" duration="500"/>
  </animation>
 </tile>
 <tile id="84">
  <animation>
   <frame tileid="84" duration="500"/>
   <frame tileid="85" duration="500"/>
  </animation>
 </tile>
 <tile id="86">
  <animation>
   <frame tileid="86" duration="500"/>
   <frame tileid="87" duration="500"/>
  </animation>
 </tile>
 <tile id="103">
  <animation>
   <frame tileid="103" duration="500"/>
   <frame tileid="104" duration="500"/>
  </animation>
 </tile>
</tileset>
