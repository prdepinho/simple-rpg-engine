
local rules = require "scripts.rules"
local animations = require "character.animations"
local Priestess = require "character.priestess"

local ArcherInstructor = Priestess:new()

function ArcherInstructor:new(o, control)
  o = o or Priestess:new(o, control)
  setmetatable(o, self)
  self.__index = self
  return o
end

function ArcherInstructor:create()
  Priestess.create(self)

  local stats = self.data.stats
  stats.inventory[1] = {code = self.name .. "_bow", name = "short_bow", type = 'weapon'}
  stats.inventory[2] = {code = self.name .. "_arrows", name = "arrow", type = "ammo", quantity = 20}
  stats.weapon = stats.inventory[1]
  stats.ammo = stats.inventory[2]
end

function ArcherInstructor:on_interact(interactor_name)
  local dialogue = {
    start = {
      text = "Mumu, take the bow and arrows, proceed to the cage and kill the rat. Equip both your bow and the arrows before going in. Press B to attack with your weapon.",
      go_to = 'end'
    }
  }

  if self.control.data.temple_rat4_dead then
    dialogue.start = {
      text = "You should not walk with a cluttered inventory, sister. Carry only what you need and if you cannot pick something up because of your encuberance, drop something down and come for it later.",
      go_to = 'end'
    }
  end

  self:add_invitation_procedure(dialogue)

  sfml_dialogue(dialogue)
end



return ArcherInstructor
